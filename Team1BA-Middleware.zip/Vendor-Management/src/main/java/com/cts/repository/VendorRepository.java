package com.cts.repository;

import org.springframework.data.repository.CrudRepository;

import com.cts.entity.Vendor;

public interface VendorRepository extends CrudRepository<Vendor, Long> {


}
